<?php
require_once("todo.class.php");

class TodoController {
    private const PATH = __DIR__."/todo.json";
    private array $todos = [];

    public function __construct() {
        $content = file_get_contents(self::PATH);
        if ($content === false) {
            throw new Exception(self::PATH . " does not exist");
        }  
        $dataArray = json_decode($content);
        if (!json_last_error()) {
            foreach($dataArray as $data) {
                if (isset($data->id) && isset($data->title))
                $this->todos[] = new Todo($data->id, $data->title, $data->description, $data->done);
            }
        }
    }

    public function loadAll() : array {
        return $this->todos;
    }

    public function load(string $id) : Todo | bool {
        foreach($this->todos as $todo) {
            if ($todo->id == $id) {
                return $todo;
            }
        }
        return false;
    }

    public function create(Todo $todo) : bool {
        // implement your code here
        // read json file
        $data = file_get_contents('todo.json');

        // decode json
        $json_arr = json_decode($data, true);

        // add data
      //  $json_arr[] = array();
        

        // encode json and save to file
        file_put_contents('todo.json', json_encode($json_arr));

        return true;
    }

    public function update(string $id, Todo $todo) : bool {
        // implement your code here
        // read file
        $data = file_get_contents('todo.json');

        // decode json to array
        $json_arr = json_decode($data, true);

        foreach ($json_arr as $key => $value) {
        if ($value[''] == '') {
        $json_arr[$key][''] = "";
    }
}

        // encode array to json and save to file
        file_put_contents('todo.json', json_encode($json_arr));
        return true;
    }

    public function delete(string $id) : bool {
        // implement your code here
           // read json file
        $data = file_get_contents('todo.json');

        // decode json to associative array
        $json_arr = json_decode($data, true);

        // get array index to delete
        $arr_index = array();
        foreach ($json_arr as $key => $value)
        {
           if ($value[''] == "")
            {
            $arr_index[] = $key;
    }
}

        // delete data
        foreach ($arr_index as $i)
        {
             unset($json_arr[$i]);
        }

        // rebase array
        $json_arr = array_values($json_arr);

        // encode array to json and save to file
        file_put_contents('todo.json', json_encode($json_arr));
           return true;
    }

    // add any additional functions you need below
}